const CACHE_NAME = 'ganglei-v1'

self.addEventListener('install', (e) => {
  self.skipWaiting()
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      cache.addAll([
        '/',
        '/index.html',
        '/icon-192.png',
        '/icon-512.png',
        '/icon-maskable.png',
      ]),
    ),
  )
})

self.addEventListener('activate', (e) => {
  e.waitUntil(self.clients.claim())
})

self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((response) => {
      if (response) return response
      return fetch(e.request)
        .then((res) => {
          if (!res || res.status !== 200 || res.type !== 'basic') return res
          const cloned = res.clone()
          caches.open(CACHE_NAME).then((cache) => cache.put(e.request, cloned))
          return res
        })
        .catch(() => {
          if (e.request.mode === 'navigate') {
            return caches.match('/index.html')
          }
        }),
    }),
  )
})
